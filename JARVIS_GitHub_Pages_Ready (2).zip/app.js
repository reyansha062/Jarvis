const $=id=>document.getElementById(id);
const answer=$("answer"),hint=$("hint"),log=$("log"),coreWrap=$("coreWrap"),mode=$("mode"),voiceStatus=$("voiceStatus"),status=$("systemStatus");

function addLog(who,text){
  const d=document.createElement("div"); d.className="line "+(who==="You"?"you":"jarvis");
  d.textContent=`[${new Date().toLocaleTimeString()}] ${who}: ${text}`;
  log.prepend(d);
}
function speak(text){
  if(!("speechSynthesis" in window)) return;
  speechSynthesis.cancel();
  const u=new SpeechSynthesisUtterance(text);
  u.rate=1; u.pitch=.88; u.volume=1;
  speechSynthesis.speak(u);
}
function reply(text){
  answer.textContent=text; hint.textContent="JARVIS is ready for your next command.";
  addLog("JARVIS",text); speak(text);
}
function openWeb(url){window.open(url,"_blank","noopener,noreferrer");}
function execute(raw){
  if(!raw.trim())return;
  addLog("You",raw); const c=raw.trim().toLowerCase();
  hint.textContent=raw;
  if(c.includes("hello")||c.includes("hi jarvis")) reply("Hello. All systems are online.");
  else if(c.includes("time")) reply("The current time is "+new Date().toLocaleTimeString([],{hour:"numeric",minute:"2-digit"}));
  else if(c.includes("date")||c.includes("today")) reply("Today is "+new Date().toLocaleDateString([],{weekday:"long",year:"numeric",month:"long",day:"numeric"}));
  else if(c.includes("open google")){reply("Opening Google.");openWeb("https://www.google.com");}
  else if(c.includes("open youtube")){reply("Opening YouTube.");openWeb("https://www.youtube.com");}
  else if(c.startsWith("youtube ")){const q=raw.slice(raw.toLowerCase().indexOf("youtube ")+8).trim();reply("Searching YouTube for "+q);openWeb("https://www.youtube.com/results?search_query="+encodeURIComponent(q));}
  else if(c.startsWith("search ")){const q=raw.slice(raw.toLowerCase().indexOf("search ")+7).trim();reply("Searching for "+q);openWeb("https://www.google.com/search?q="+encodeURIComponent(q));}
  else if(c.includes("who are you")) reply("I am JARVIS, your browser-based personal AI assistant.");
  else if(c.includes("clear log")){log.innerHTML="";reply("Activity log cleared.");}
  else reply("Command not recognized. Try time, date, open Google, open YouTube, or search followed by your query.");
}

const SR=window.SpeechRecognition||window.webkitSpeechRecognition;
let recognition=null;
if(SR){
  recognition=new SR(); recognition.lang="en-IN"; recognition.continuous=false; recognition.interimResults=false;
  recognition.onstart=()=>{coreWrap.classList.add("listening");mode.textContent="LISTENING...";voiceStatus.textContent="LISTENING";status.textContent="VOICE ACTIVE";};
  recognition.onend=()=>{coreWrap.classList.remove("listening");mode.textContent="VOICE READY";voiceStatus.textContent="READY";status.textContent="SYSTEM ONLINE";};
  recognition.onerror=e=>{coreWrap.classList.remove("listening");hint.textContent="Microphone error: "+e.error;mode.textContent="MIC ERROR";};
  recognition.onresult=e=>execute(e.results[0][0].transcript);
}else{
  $("mic").disabled=true;mode.textContent="TEXT ONLY";voiceStatus.textContent="UNAVAILABLE";
}

$("mic").onclick=()=>{if(recognition){try{recognition.start()}catch(e){}}};
$("stop").onclick=()=>{if(recognition)recognition.stop();speechSynthesis?.cancel();};
$("send").onclick=()=>{execute($("command").value);$("command").value="";};
$("command").onkeydown=e=>{if(e.key==="Enter"){$("send").click()}};
document.querySelectorAll("[data-cmd]").forEach(b=>b.onclick=()=>execute(b.dataset.cmd));
$("clear").onclick=()=>log.innerHTML="";
setInterval(()=>{$("clock").textContent=new Date().toLocaleTimeString()},1000);
reply("Good day. I am JARVIS. All systems are online.");
