JARVIS GitHub Pages replacement

UPLOAD THESE 3 FILES TO YOUR GITHUB PAGES REPOSITORY:
- index.html
- style.css
- app.js

IMPORTANT:
Replace the old index.html with this one. Keep the filenames exactly as shown.

Then commit/push the changes. GitHub Pages will publish the new interface at your existing /Jarvis/ URL.

VOICE:
Open the site in Chrome and allow microphone permission. Click START LISTENING.

SUPPORTED COMMANDS:
- What is the time
- What is today's date
- Open Google
- Open YouTube
- Search Python tutorials
- YouTube relaxing music
- Who are you

NOTE:
A GitHub Pages website cannot directly run Windows commands or ADB. Those require a local backend/bridge. This version is fully browser-based and safe to host on GitHub Pages.
