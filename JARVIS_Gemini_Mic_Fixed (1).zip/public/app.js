const $=id=>document.getElementById(id);
let recognition=null, speaking=true, busy=false;

function log(who,text){const d=document.createElement("div");d.className="line "+(who==="You"?"you":"jarvis");d.textContent=`[${new Date().toLocaleTimeString()}] ${who}: ${text}`;$("log").prepend(d)}
function speak(text){if(!speaking||!window.speechSynthesis)return;speechSynthesis.cancel();const u=new SpeechSynthesisUtterance(text);u.rate=.97;u.pitch=.85;speechSynthesis.speak(u)}
function show(text,detail=""){ $("answer").textContent=text; $("detail").textContent=detail; log("JARVIS",text); speak(text)}
function doAction(a){
 if(!a||!a.type)return;
 const q=encodeURIComponent(a.query||"");
 const urls={google:"https://www.google.com/search?q="+q,youtube:"https://www.youtube.com/results?search_query="+q,maps:"https://www.google.com/maps/search/?api=1&query="+q,weather:"https://www.google.com/search?q="+encodeURIComponent("weather "+(a.query||""))};
 if(a.type==="open_url"&&a.url)window.open(a.url,"_blank","noopener,noreferrer");
 else if(urls[a.type])window.open(urls[a.type],"_blank","noopener,noreferrer");
 else if(a.type==="timer"){const s=Math.max(1,Number(a.seconds)||1);setTimeout(()=>{show("Timer complete.","Your "+s+" second timer has finished.");alert("JARVIS: Timer complete.");},s*1000)}
}
async function ask(text){
 if(busy)return; text=text.trim(); if(!text)return;
 busy=true;$("status").textContent="THINKING";$("mode").textContent="GEMINI THINKING";$("orb").classList.add("listening");log("You",text);
 try{
  const r=await fetch("/api/chat",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({message:text})});
  const data=await r.json(); if(!r.ok)throw new Error(data.error||"Backend error");
  show(data.reply||"I received that.",data.action?"Action: "+data.action.type:"Gemini response");
  if(data.action)doAction(data.action);
 }catch(e){show("I couldn't reach my Gemini brain.","Make sure the backend is running and GEMINI_API_KEY is configured.");console.error(e)}
 finally{busy=false;$("status").textContent="ONLINE";$("mode").textContent="GEMINI READY";$("orb").classList.remove("listening")}
}
$("send").onclick=()=>{$("cmd").value&&(ask($("cmd").value),$("cmd").value="")};
$("cmd").onkeydown=e=>{if(e.key==="Enter")$("send").click()};
document.querySelectorAll("[data-q]").forEach(b=>b.onclick=()=>ask(b.dataset.q));
$("clear").onclick=()=>{$("log").innerHTML=""};
$("stop").onclick=()=>{try{recognition?.stop()}catch{}speechSynthesis?.cancel();$("orb").classList.remove("listening");$("status").textContent="ONLINE"};
const SR=window.SpeechRecognition||window.webkitSpeechRecognition;
let recognition=null, activated=false, listening=false, restarting=false, shouldListen=false;

function setMic(state,text){
  $("micDot").className=state;
  $("micState").textContent=text;
}
function setMode(text){$("mode").textContent=text}

async function testMicrophone(){
  if(!navigator.mediaDevices?.getUserMedia){
    setMic("error","MIC API UNAVAILABLE"); setMode("USE HTTPS / LOCALHOST"); return;
  }
  try{
    const stream=await navigator.mediaDevices.getUserMedia({audio:true});
    const tracks=stream.getAudioTracks();
    setMic("live","MICROPHONE WORKS");
    setMode("MIC TEST PASSED");
    $("detail").textContent="Microphone detected: "+(tracks[0]?.label||"audio input")+".";
    tracks.forEach(t=>t.stop());
  }catch(e){
    setMic("error","MICROPHONE BLOCKED");
    setMode("ALLOW MICROPHONE");
    $("detail").textContent="Chrome blocked microphone access. Click the 🔒 icon beside the address bar and allow Microphone.";
    console.error(e);
  }
}

function startRecognition(){
  if(!recognition||!activated||!shouldListen||listening||restarting)return;
  try{restarting=true;recognition.start()}catch(e){restarting=false}
}

if(!SR){
  $("activate").disabled=true;
  $("mic").disabled=true;
  $("micTest").disabled=true;
  setMic("error","VOICE NOT SUPPORTED");
  setMode("USE CHROME OR EDGE");
}else{
  recognition=new SR();
  recognition.lang="en-IN";
  recognition.continuous=false;
  recognition.interimResults=false;
  recognition.maxAlternatives=1;

  recognition.onstart=()=>{
    restarting=false; listening=true;
    setMic("live","LISTENING");
    setMode("LISTENING FOR “HEY JARVIS”");
    $("orb").classList.add("listening");
  };

  recognition.onresult=e=>{
    const heard=e.results[e.results.length-1][0].transcript.trim();
    $("detail").textContent="Heard: “"+heard+"”";
    const match=heard.match(/(?:hey|ok|okay)\s+jarvis\b(.*)/i);
    if(!match){setMode("HEARD — WAITING FOR “HEY JARVIS”");return}
    const command=match[1].trim();
    if(command)ask(command); else show("Yes?","I'm listening.");
  };

  recognition.onerror=e=>{
    listening=false; restarting=false; $("orb").classList.remove("listening");
    if(e.error==="not-allowed"||e.error==="service-not-allowed"){
      setMic("error","MICROPHONE BLOCKED");
      setMode("ALLOW MICROPHONE");
      shouldListen=false;
      $("detail").textContent="Microphone permission was denied. Use the browser lock/site controls to allow Microphone, then click ACTIVATE JARVIS again.";
      return;
    }
    if(e.error==="audio-capture"){
      setMic("error","NO MIC FOUND"); setMode("CHECK MICROPHONE");
      $("detail").textContent="Windows did not provide an audio input. Check Settings → System → Sound → Input.";
      return;
    }
    setMode("RECONNECTING…");
    setTimeout(startRecognition,700);
  };

  recognition.onend=()=>{
    listening=false;$("orb").classList.remove("listening");
    if(activated&&shouldListen){setMode("RECONNECTING…");setTimeout(startRecognition,500)}
    else {setMic("","MICROPHONE OFF");setMode("VOICE STOPPED")}
  };

  $("activate").onclick=async()=>{
    activated=true;shouldListen=true;
    $("activate").classList.add("active");
    $("activate").textContent="✓ JARVIS ACTIVATED";
    await testMicrophone();
    if(activated) setTimeout(startRecognition,300);
  };

  $("micTest").onclick=testMicrophone;

  $("mic").onclick=()=>{
    activated=true;shouldListen=true;
    $("activate").classList.add("active");
    $("activate").textContent="✓ JARVIS ACTIVATED";
    startRecognition();
  };

  $("stop").onclick=()=>{
    shouldListen=false;activated=false;
    $("activate").classList.remove("active");
    $("activate").textContent="🎙 ACTIVATE JARVIS";
    try{recognition.stop()}catch{}
    speechSynthesis?.cancel();
    setMic("","MICROPHONE OFF");
    setMode("VOICE STOPPED");
    $("orb").classList.remove("listening");
  };
}
fetch("/api/health")
  .then(r=>r.json())
  .then(x=>{$("backend").textContent=x.ok?"ONLINE":"API KEY MISSING"})
  .catch(()=>{$("backend").textContent="OFFLINE"});
