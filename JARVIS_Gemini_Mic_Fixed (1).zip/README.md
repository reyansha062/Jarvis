# JARVIS + Gemini

## What this is
A complete JARVIS web app with a Node.js backend and Gemini intelligence. The browser sends natural-language requests to `/api/chat`; the server calls Gemini and returns a safe structured response. The browser can then perform simple actions such as Google/YouTube/Maps searches and timers.

## Files
- `public/index.html` — interface
- `public/style.css` — UI
- `public/app.js` — voice, UI, API client, browser actions
- `server.js` — secure Gemini backend
- `.env.example` — configuration template
- `.gitignore` — keeps your API key out of Git
- `package.json` — dependencies

## Setup
1. Install Node.js 18+.
2. Create a Gemini API key in Google AI Studio.
3. Copy `.env.example` to `.env`.
4. Put your key after `GEMINI_API_KEY=`.
5. Run:
   `npm install`
   `npm start`
6. Open `http://localhost:3000`.

IMPORTANT: Never paste your real API key into `public/app.js`, `index.html`, or a public GitHub repository. Keep it in `.env` or your hosting provider's secret/environment-variable settings.

## GitHub Pages
GitHub Pages can host the frontend, but it cannot run `server.js`. To use Gemini from a public GitHub Pages site, deploy this Node backend separately (for example on a server/host that supports Node), then change the frontend API URL from `/api/chat` to your backend URL and enable CORS for your Pages domain. Do not expose the API key in the frontend.

## Natural language
Gemini can decide whether a request needs a browser action. The backend returns structured JSON with `reply` and an optional `action`.

\n## Always-listening mode
The browser now starts speech recognition automatically and waits for the wake phrase **Hey JARVIS**.
Chrome/Edge must have microphone permission. Browser speech recognition can still pause or stop because of browser/OS microphone rules; the app automatically attempts to restart it.
For privacy, recognition is handled by the browser speech-recognition service; the app only sends a command to the Gemini backend after the wake phrase is detected.

\n## Microphone troubleshooting
1. Use Chrome or Edge.
2. Open JARVIS through `http://localhost:3000` or HTTPS.
3. Click **ACTIVATE JARVIS**.
4. Click **Allow** when Chrome asks for microphone permission.
5. Use **TEST MICROPHONE** to verify that Windows/browser can see an audio input.
6. After activation, say **Hey JARVIS** followed by your command.
