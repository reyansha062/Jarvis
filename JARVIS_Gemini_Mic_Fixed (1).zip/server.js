import "dotenv/config";
import express from "express";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { GoogleGenAI } from "@google/genai";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
const PORT = process.env.PORT || 3000;
const MODEL = process.env.GEMINI_MODEL || "gemini-3.6-flash";

if (!process.env.GEMINI_API_KEY) console.warn("WARNING: GEMINI_API_KEY is not configured.");

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });

const systemInstruction = `
You are JARVIS, a concise, intelligent personal assistant.
Understand natural language, slang, follow-up questions, and imperfect phrasing.
Be helpful and conversational. Never claim you performed an action unless the action object requests it.
When the user wants a browser action, return a single action object.
Supported action types:
- google: web search; query required
- youtube: YouTube search; query required
- maps: Google Maps search; query required
- weather: weather search; query optional
- open_url: open a URL; url required
- timer: browser timer; seconds required
For ordinary questions, action must be null.
For memory requests, explain that this demo keeps only server-session context; do not invent permanent memory.
Return JSON matching the supplied schema.
`;

const responseSchema = {
  type: "object",
  properties: {
    reply: { type: "string" },
    action: {
      type: "object",
      nullable: true,
      properties: {
        type: { type: "string", enum: ["google","youtube","maps","weather","open_url","timer"] },
        query: { type: "string", nullable: true },
        url: { type: "string", nullable: true },
        seconds: { type: "number", nullable: true }
      },
      required: ["type"]
    }
  },
  required: ["reply","action"]
};

app.use(express.json({ limit: "32kb" }));
app.use(express.static(path.join(__dirname, "public")));

app.get("/api/health", (_req,res)=>res.json({ok:Boolean(process.env.GEMINI_API_KEY), model:MODEL}));

app.post("/api/chat", async (req,res)=>{
  try {
    const message = String(req.body?.message || "").trim();
    if (!message) return res.status(400).json({error:"Message is required."});
    if (!process.env.GEMINI_API_KEY) return res.status(503).json({error:"GEMINI_API_KEY is not configured on the server."});

    const response = await ai.models.generateContent({
      model: MODEL,
      contents: message,
      config: {
        systemInstruction,
        responseMimeType: "application/json",
        responseSchema
      }
    });

    let data;
    try { data = JSON.parse(response.text); }
    catch { data = {reply: response.text || "I couldn't format that response.", action:null}; }

    res.json(data);
  } catch (err) {
    console.error(err);
    res.status(500).json({error:"Gemini request failed.", detail: process.env.NODE_ENV === "development" ? String(err.message) : undefined});
  }
});

app.get("*",(req,res)=>{
  if (req.path.startsWith("/api/")) return res.status(404).json({error:"Not found"});
  res.sendFile(path.join(__dirname,"public","index.html"));
});

app.listen(PORT,()=>console.log(`JARVIS running at http://localhost:${PORT}`));
