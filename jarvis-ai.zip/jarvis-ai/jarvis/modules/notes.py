"""A tiny notes system: append notes to a text file and read them back."""

import datetime
import os

from jarvis.speech import speak
from jarvis import config


def add_note(content: str) -> None:
    if not content:
        speak("What would you like me to note down?")
        return

    timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M")
    with open(config.NOTES_FILE, "a", encoding="utf-8") as f:
        f.write(f"[{timestamp}] {content}\n")

    speak("Got it, I've noted that down.")


def read_notes() -> None:
    if not os.path.exists(config.NOTES_FILE):
        speak("You don't have any notes yet.")
        return

    with open(config.NOTES_FILE, "r", encoding="utf-8") as f:
        lines = [line.strip() for line in f.readlines() if line.strip()]

    if not lines:
        speak("Your notes file is empty.")
        return

    speak(f"You have {len(lines)} notes. Here are the most recent ones.")
    for line in lines[-5:]:
        speak(line)
