"""System-related actions: time, date, battery, volume, launching apps."""

import datetime
import platform
import subprocess

from jarvis.speech import speak

try:
    import psutil
except ImportError:
    psutil = None


def tell_time() -> None:
    now = datetime.datetime.now().strftime("%I:%M %p")
    speak(f"The time is {now}.")


def tell_date() -> None:
    today = datetime.datetime.now().strftime("%B %d, %Y")
    speak(f"Today's date is {today}.")


def battery_status() -> None:
    if psutil is None:
        speak("The psutil package isn't installed, so I can't check your battery. Run pip install psutil.")
        return
    battery = psutil.sensors_battery()
    if battery is None:
        speak("I couldn't detect a battery on this device.")
        return
    plugged = "and charging" if battery.power_plugged else "and not charging"
    speak(f"Battery is at {int(battery.percent)} percent {plugged}.")


def change_volume(up: bool = True) -> None:
    system_name = platform.system()
    try:
        if system_name == "Darwin":  # macOS
            change = "10" if up else "-10"
            subprocess.run(
                ["osascript", "-e", f"set volume output volume (output volume of (get volume settings) + {change})"]
            )
        elif system_name == "Windows":
            # Requires nircmd or similar on Windows for real volume control.
            speak("Volume control on Windows needs an extra tool like nircmd — see the README.")
            return
        else:  # Linux (assumes PulseAudio)
            step = "+10%" if up else "-10%"
            subprocess.run(["amixer", "-D", "pulse", "sset", "Master", step])
        speak(f"Volume {'up' if up else 'down'}.")
    except Exception:
        speak("I couldn't change the volume on this system.")


def open_app(name: str) -> None:
    system_name = platform.system()
    apps = {
        "notepad": {"Windows": "notepad", "Darwin": "TextEdit", "Linux": "gedit"},
        "calculator": {"Windows": "calc", "Darwin": "Calculator", "Linux": "gnome-calculator"},
    }

    target = apps.get(name, {}).get(system_name)
    if not target:
        speak(f"I don't know how to open {name} on {system_name}.")
        return

    try:
        if system_name == "Darwin":
            subprocess.Popen(["open", "-a", target])
        else:
            subprocess.Popen([target])
        speak(f"Opening {name}.")
    except Exception:
        speak(f"I couldn't open {name} on this system.")
