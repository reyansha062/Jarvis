"""Web-related actions: Wikipedia lookups, opening sites, Google search."""

import webbrowser

from jarvis.speech import speak

try:
    import wikipedia
except ImportError:
    wikipedia = None


def search_wikipedia(term: str) -> None:
    if not term:
        speak("What would you like me to look up on Wikipedia?")
        return
    if wikipedia is None:
        speak("The wikipedia package isn't installed. Run pip install wikipedia.")
        return

    speak(f"Searching Wikipedia for {term}...")
    try:
        summary = wikipedia.summary(term, sentences=2)
        speak(summary)
    except wikipedia.DisambiguationError as e:
        options = ", ".join(e.options[:5])
        speak(f"That's a bit ambiguous. Did you mean: {options}?")
    except Exception:
        speak("I couldn't find anything on that topic.")


def open_site(url: str, name: str) -> None:
    speak(f"Opening {name}.")
    webbrowser.open(url)


def google_search(term: str) -> None:
    if not term:
        speak("What would you like me to search for?")
        return
    speak(f"Searching for {term}.")
    webbrowser.open(f"https://www.google.com/search?q={term}")
