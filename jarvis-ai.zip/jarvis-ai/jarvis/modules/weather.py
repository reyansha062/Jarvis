"""Weather lookups via the OpenWeatherMap API (free tier)."""

import requests

from jarvis.speech import speak
from jarvis import config


def get_weather(city: str) -> None:
    if not city:
        speak("Which city's weather would you like?")
        return

    if not config.OPENWEATHER_API_KEY:
        speak(
            "Weather lookups need a free OpenWeatherMap API key. "
            "Add it as OPENWEATHER_API_KEY in your .env file — see the README."
        )
        return

    url = "https://api.openweathermap.org/data/2.5/weather"
    params = {"q": city, "appid": config.OPENWEATHER_API_KEY, "units": "metric"}

    try:
        response = requests.get(url, params=params, timeout=5)
        data = response.json()

        if response.status_code != 200:
            speak(f"I couldn't find weather data for {city}.")
            return

        temp = data["main"]["temp"]
        feels_like = data["main"]["feels_like"]
        description = data["weather"][0]["description"]

        speak(
            f"It's currently {temp:.0f} degrees Celsius in {city.title()}, "
            f"feels like {feels_like:.0f}, with {description}."
        )
    except requests.RequestException:
        speak("I couldn't reach the weather service. Check your internet connection.")
