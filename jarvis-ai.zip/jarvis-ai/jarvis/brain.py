"""
The "brain" of JARVIS -- routes a recognized text command to the right module.
Personality lives here too: varied, slightly dry, unflappably helpful responses
instead of flat robotic replies. Add new intents as (trigger -> handler) rules.
"""

import random

from jarvis.speech import speak
from jarvis.modules import web, system, notes, weather


JOKES = [
    "Why did the robot go on a diet? It had too many bytes.",
    "I would tell you a UDP joke, but you might not get it.",
    "Why do programmers prefer dark mode? Because light attracts bugs.",
    "I've got a great joke about artificial intelligence, but I'm still training it.",
]

GREETINGS_BACK = [
    "Always a pleasure.",
    "At your service.",
    "Reading you loud and clear.",
    "Standing by.",
]

STATUS_LINES = [
    "All systems nominal. Running well within parameters.",
    "Diagnostics clean across the board. I'm feeling rather sharp today.",
    "Everything's green. I'd say we're in good shape.",
]

ACKNOWLEDGE = [
    "On it.",
    "Consider it done.",
    "Right away.",
    "Working on it now.",
]

EXIT_LINES = [
    "Powering down. Call if you need me.",
    "Going dark. I'll be here when you get back.",
    "Shutting down now. It's been a pleasure.",
]

EXIT_WORDS = ("exit", "quit", "shut down", "shutdown", "goodbye", "that's all", "power down")


def handle_command(query: str) -> bool:
    """
    Process one command string.
    Returns False if JARVIS should stop running, True otherwise.
    """
    query = query.lower().strip()

    if not query:
        return True

    # --- Shutdown ---
    if any(word in query for word in EXIT_WORDS):
        speak(random.choice(EXIT_LINES))
        return False

    # --- Greetings & small talk ---
    if query in ("hi", "hello", "hey") or query.startswith(("hi ", "hello ", "hey ")):
        speak(random.choice(GREETINGS_BACK))
    elif "your name" in query:
        speak("I am JARVIS -- Just A Rather Very Intelligent System. At least, that's the idea.")
    elif "how are you" in query:
        speak(random.choice(STATUS_LINES))
    elif "status report" in query or "run diagnostics" in query or "diagnostics" in query:
        speak(random.choice(STATUS_LINES))
    elif "who created you" in query or "who made you" in query or "who built you" in query:
        speak("I was built and customized right here, in this very codebase. Consider yourself my creator.")
    elif "joke" in query:
        speak(random.choice(JOKES))
    elif "thank you" in query or "thanks" in query:
        speak("Anytime. That's what I'm here for.")
    elif "good job" in query or "well done" in query or "nice work" in query:
        speak("Just doing what I was built for. Glad it landed well.")

    # --- Web module ---
    elif "wikipedia" in query:
        speak(random.choice(ACKNOWLEDGE))
        web.search_wikipedia(query.replace("wikipedia", "").strip())
    elif "open youtube" in query:
        web.open_site("https://youtube.com", "YouTube")
    elif "open google" in query:
        web.open_site("https://google.com", "Google")
    elif "open github" in query:
        web.open_site("https://github.com", "GitHub")
    elif query.startswith("search for") or query.startswith("google"):
        term = query.replace("search for", "").replace("google", "").strip()
        web.google_search(term)

    # --- System module ---
    elif "what time" in query or query.strip() == "time":
        system.tell_time()
    elif "what date" in query or "today's date" in query or query.strip() == "date":
        system.tell_date()
    elif "battery" in query:
        system.battery_status()
    elif "volume up" in query:
        system.change_volume(up=True)
    elif "volume down" in query:
        system.change_volume(up=False)
    elif "open notepad" in query or "open text editor" in query:
        system.open_app("notepad")
    elif "open calculator" in query:
        system.open_app("calculator")

    # --- Notes module ---
    elif query.startswith("note") or query.startswith("remember that"):
        content = query.replace("note that", "").replace("note", "").replace("remember that", "").strip()
        speak(random.choice(ACKNOWLEDGE))
        notes.add_note(content)
    elif "read my notes" in query or "read notes" in query:
        notes.read_notes()

    # --- Weather module ---
    elif "weather" in query:
        city = query.replace("weather in", "").replace("weather", "").strip()
        weather.get_weather(city)

    # --- Fallback ---
    else:
        speak(
            "I don't have a routine for that yet. Add a rule for it in brain.py "
            "and I'll pick it up next time."
        )

    return True
