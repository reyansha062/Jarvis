"""
JARVIS - Just A Rather Very Intelligent System
Entry point. Run this file to start the assistant.

    python -m jarvis.main               # voice mode
    python -m jarvis.main --text        # text-only mode (no mic/speakers needed)
    python -m jarvis.main --gui         # voice mode + animated HUD
    python -m jarvis.main --gui --text  # text mode + animated HUD
"""

import argparse
import datetime
import sys
import threading

from jarvis.speech import speak, listen
from jarvis.brain import handle_command
from jarvis import config


WAKE_WORDS = ("jarvis", "hey jarvis", "ok jarvis")

GREETINGS = [
    "{time_greeting}, {user}. {name} online. How can I help?",
    "{time_greeting}, {user}. All systems are up and I'm ready when you are.",
    "{time_greeting}, {user}. {name} at your service.",
]


def wish_user() -> None:
    import random

    hour = datetime.datetime.now().hour
    if hour < 12:
        time_greeting = "Good morning"
    elif hour < 18:
        time_greeting = "Good afternoon"
    else:
        time_greeting = "Good evening"

    template = random.choice(GREETINGS)
    speak(template.format(time_greeting=time_greeting, user=config.USER_NAME, name=config.ASSISTANT_NAME))


def strip_wake_word(query: str) -> str:
    lowered = query.lower().strip()
    for wake in WAKE_WORDS:
        if lowered.startswith(wake):
            return lowered[len(wake):].strip(" ,.")
    return lowered


def run_voice_mode() -> None:
    wish_user()
    running = True
    while running:
        raw = listen()
        if not raw:
            continue

        query = strip_wake_word(raw)
        if not query:
            speak("Yes? I'm listening.")
            continue

        running = handle_command(query)


def run_text_mode() -> None:
    wish_user()
    print("(Text mode -- type your commands. Type 'exit' to quit.)\n")
    running = True
    while running:
        try:
            query = input("You: ").strip().lower()
        except (EOFError, KeyboardInterrupt):
            print()
            break
        if not query:
            continue
        running = handle_command(query)


def main() -> None:
    parser = argparse.ArgumentParser(description=f"{config.ASSISTANT_NAME} AI Assistant")
    parser.add_argument(
        "--text", action="store_true", help="Run in text-only mode (no microphone/speaker needed)"
    )
    parser.add_argument(
        "--gui", action="store_true", help="Launch the animated arc-reactor HUD interface"
    )
    args = parser.parse_args()

    if args.gui:
        from jarvis.hud import create_hud

        hud = create_hud(config.ASSISTANT_NAME)
        target = run_text_mode if args.text else run_voice_mode
        worker = threading.Thread(target=target, daemon=True)
        worker.start()
        hud.run()
        return

    try:
        if args.text:
            run_text_mode()
        else:
            run_voice_mode()
    except KeyboardInterrupt:
        print("\nShutting down. Goodbye.")
        sys.exit(0)


if __name__ == "__main__":
    main()
