"""
Central configuration for JARVIS.
Edit these values (or override via a .env file) to personalize your assistant.
"""

import os

# --- Identity ---
ASSISTANT_NAME = os.getenv("ASSISTANT_NAME", "JARVIS")
USER_NAME = os.getenv("USER_NAME", "sir")

# --- Voice settings ---
VOICE_RATE = int(os.getenv("VOICE_RATE", "175"))
VOICE_INDEX = int(os.getenv("VOICE_INDEX", "0"))  # 0 = usually male, 1 = usually female (OS-dependent)

# --- Optional API keys (leave blank to disable that feature) ---
OPENWEATHER_API_KEY = os.getenv("OPENWEATHER_API_KEY", "")
NEWS_API_KEY = os.getenv("NEWS_API_KEY", "")

# --- Behavior ---
SPEECH_LANGUAGE = os.getenv("SPEECH_LANGUAGE", "en-in")
NOTES_FILE = os.getenv("NOTES_FILE", "jarvis_notes.txt")
