"""
JARVIS HUD — an animated, arc-reactor-style visual interface.
Runs in the main thread while the assistant logic runs in a background thread,
communicating over a thread-safe queue.

Launch with:
    python -m jarvis.main --gui
    python -m jarvis.main --gui --text
"""

import math
import queue
import tkinter as tk

BG = "#000814"
CYAN = "#00d9ff"
CYAN_DIM = "#0077a8"
TEXT_DIM = "#7fdfff"


class JarvisHUD:
    def __init__(self, assistant_name: str = "J.A.R.V.I.S."):
        self.root = tk.Tk()
        self.root.title(assistant_name)
        self.root.configure(bg=BG)
        self.root.geometry("520x620")
        self.root.minsize(420, 500)

        self._queue: "queue.Queue[tuple[str, str]]" = queue.Queue()
        self._angle = 0.0
        self._pulse = 0.0
        self._state = "IDLE"

        self._build_ui(assistant_name)
        self._animate()
        self.root.after(100, self._process_queue)

    # ---------- UI construction ----------

    def _build_ui(self, assistant_name: str) -> None:
        tk.Label(
            self.root, text=assistant_name, fg=CYAN, bg=BG, font=("Consolas", 20, "bold")
        ).pack(pady=(14, 0))

        self.canvas = tk.Canvas(self.root, width=480, height=280, bg=BG, highlightthickness=0)
        self.canvas.pack(pady=6)

        self.status_var = tk.StringVar(value="INITIALIZING...")
        tk.Label(
            self.root, textvariable=self.status_var, fg=CYAN, bg=BG, font=("Consolas", 13, "bold")
        ).pack()

        self.log_box = tk.Text(
            self.root,
            height=16,
            bg="#01111f",
            fg=TEXT_DIM,
            insertbackground=TEXT_DIM,
            font=("Consolas", 10),
            bd=0,
            wrap="word",
            padx=10,
            pady=8,
        )
        self.log_box.pack(padx=14, pady=(10, 14), fill="both", expand=True)
        self.log_box.configure(state="disabled")

    # ---------- Arc-reactor animation ----------

    def _animate(self) -> None:
        self.canvas.delete("ring")
        cx, cy = 240, 140

        # Idle = slow calm pulse, Listening = fast bright pulse, Speaking = flicker
        speed = {"IDLE": 2.5, "LISTENING": 6, "PROCESSING": 5, "SPEAKING": 8}.get(self._state, 2.5)
        self._angle = (self._angle + speed) % 360
        self._pulse = (self._pulse + 1) % 60
        pulse_r = 6 * math.sin(math.radians(self._pulse * 6))

        core_color = CYAN if self._state != "IDLE" else CYAN_DIM

        rings = [
            (95 + pulse_r, 3, CYAN),
            (72, 2, CYAN if self._state in ("LISTENING", "SPEAKING") else CYAN_DIM),
            (50, 4, core_color),
        ]
        for i, (radius, width, color) in enumerate(rings):
            start = (self._angle * (i + 1)) % 360
            extent = 100 + 40 * math.sin(math.radians(self._angle + i * 40))
            self.canvas.create_arc(
                cx - radius, cy - radius, cx + radius, cy + radius,
                start=start, extent=extent, style="arc",
                outline=color, width=width, tags="ring",
            )

        self.canvas.create_oval(
            cx - 18, cy - 18, cx + 18, cy + 18, fill=core_color, outline="", tags="ring"
        )

        self.root.after(40, self._animate)

    # ---------- Thread-safe message queue ----------

    def _process_queue(self) -> None:
        try:
            while True:
                kind, payload = self._queue.get_nowait()
                if kind == "status":
                    self._state = payload
                    self.status_var.set(payload)
                elif kind == "log":
                    self.log_box.configure(state="normal")
                    self.log_box.insert("end", payload + "\n")
                    self.log_box.see("end")
                    self.log_box.configure(state="disabled")
        except queue.Empty:
            pass
        self.root.after(100, self._process_queue)

    # ---------- Public API (safe to call from any thread) ----------

    def set_status(self, text: str) -> None:
        self._queue.put(("status", text))

    def log(self, text: str) -> None:
        self._queue.put(("log", text))

    def run(self) -> None:
        self.root.mainloop()


_hud_instance: "JarvisHUD | None" = None


def create_hud(assistant_name: str = "J.A.R.V.I.S.") -> JarvisHUD:
    global _hud_instance
    _hud_instance = JarvisHUD(assistant_name)
    return _hud_instance


def get_hud() -> "JarvisHUD | None":
    return _hud_instance
