"""
Handles all speech input (microphone -> text) and output (text -> voice)
so the rest of the codebase never has to touch pyttsx3 / speech_recognition directly.

If a HUD is running (jarvis.hud), this module pushes status updates and
transcript lines to it automatically -- no changes needed elsewhere.
"""

import pyttsx3
import speech_recognition as sr

from jarvis import config
from jarvis.hud import get_hud

_engine = pyttsx3.init()
_voices = _engine.getProperty("voices")
if _voices:
    index = config.VOICE_INDEX if config.VOICE_INDEX < len(_voices) else 0
    _engine.setProperty("voice", _voices[index].id)
_engine.setProperty("rate", config.VOICE_RATE)

_recognizer = sr.Recognizer()


def speak(text: str) -> None:
    """Speak text out loud, print it, and mirror it to the HUD if one is running."""
    print(f"{config.ASSISTANT_NAME}: {text}")

    hud = get_hud()
    if hud:
        hud.set_status("SPEAKING")
        hud.log(f"{config.ASSISTANT_NAME}: {text}")

    _engine.say(text)
    _engine.runAndWait()

    if hud:
        hud.set_status("IDLE")


def listen(timeout: int = 5, phrase_time_limit: int = 8) -> str:
    """
    Listen on the default microphone and return recognized text (lowercased).
    Returns an empty string if nothing usable was heard.
    """
    hud = get_hud()

    try:
        with sr.Microphone() as source:
            print("Listening...")
            if hud:
                hud.set_status("LISTENING")
            _recognizer.pause_threshold = 0.8
            _recognizer.adjust_for_ambient_noise(source, duration=0.5)
            audio = _recognizer.listen(source, timeout=timeout, phrase_time_limit=phrase_time_limit)
    except sr.WaitTimeoutError:
        if hud:
            hud.set_status("IDLE")
        return ""
    except OSError:
        speak("I can't find a working microphone. Try text mode with --text instead.")
        return ""

    if hud:
        hud.set_status("PROCESSING")

    try:
        print("Recognizing...")
        query = _recognizer.recognize_google(audio, language=config.SPEECH_LANGUAGE)
        print(f"You said: {query}")
        if hud:
            hud.log(f"You: {query}")
            hud.set_status("IDLE")
        return query.lower()
    except sr.UnknownValueError:
        if hud:
            hud.set_status("IDLE")
        speak("Sorry, I didn't catch that.")
        return ""
    except sr.RequestError:
        if hud:
            hud.set_status("IDLE")
        speak("My speech recognition service seems to be unavailable right now.")
        return ""
