# JARVIS AI 🤖

A Python voice assistant inspired by Tony Stark's JARVIS from the Avengers/Iron Man films.
Speak to it, or type to it, and it'll open websites, answer questions, check the
weather, take notes, and more — all running locally on your machine.

## Features

- 🎙️ Voice input (speech-to-text) and voice output (text-to-speech)
- ⌨️ Text-only mode if you don't want to deal with a microphone
- 🖥️ **Animated arc-reactor HUD** — a glowing, pulsing holographic-style interface with a live transcript, inspired by JARVIS's on-screen presence in the films
- 🗣️ **Personality** — varied, dry, unflappable responses instead of flat robotic replies (no two greetings sound the same)
- 🌐 Web search, Wikipedia lookups, opening sites (YouTube, Google, GitHub)
- 🕒 Time, date, and battery status
- 📝 Simple note-taking ("note that I need to buy milk")
- ☁️ Weather lookups (via free OpenWeatherMap API)
- 🔊 Volume control, launching common apps
- 🧩 Modular design — easy to add new commands

## Project structure

```
jarvis-ai/
├── jarvis/
│   ├── main.py        # entry point, wake-word loop, text mode
│   ├── brain.py        # routes commands to the right module
│   ├── speech.py       # text-to-speech / speech-to-text wrapper
│   ├── config.py        # settings, pulled from .env
│   ├── hud.py            # animated arc-reactor HUD (Tkinter)
│   └── modules/
│       ├── web.py       # Wikipedia, Google, opening sites
│       ├── system.py    # time, date, battery, volume, apps
│       ├── notes.py     # note-taking
│       └── weather.py   # weather lookups
├── requirements.txt
├── .env.example
└── README.md
```

## Setup

1. **Clone the repo**
   ```bash
   git clone https://github.com/your-username/jarvis-ai.git
   cd jarvis-ai
   ```

2. **Create a virtual environment (recommended)**
   ```bash
   python -m venv venv
   source venv/bin/activate   # Windows: venv\Scripts\activate
   ```

3. **Install dependencies**
   ```bash
   pip install -r requirements.txt
   ```

   `PyAudio` can be the trickiest one to install:
   - **Windows:** `pip install pyaudio` usually just works
   - **macOS:** `brew install portaudio && pip install pyaudio`
   - **Linux:** `sudo apt-get install python3-pyaudio portaudio19-dev`

4. **(Optional) configure your assistant**
   ```bash
   cp .env.example .env
   ```
   Edit `.env` to set your name, a custom assistant name, and (optionally) an
   [OpenWeatherMap API key](https://openweathermap.org/api) for weather lookups.

## Usage

**Voice mode** (default — needs a microphone and speakers):
```bash
python -m jarvis.main
```

**Text mode** (no microphone/speaker required, good for testing):
```bash
python -m jarvis.main --text
```

**HUD mode** (adds the animated arc-reactor visual — combine with either mode above):
```bash
python -m jarvis.main --gui           # voice + HUD
python -m jarvis.main --gui --text    # text + HUD
```

The HUD is built with Tkinter (included with Python). On Linux, if it's missing, install it with:
```bash
sudo apt-get install python3-tk
```

Then just talk to it (or type):

- "What time is it?"
- "Open YouTube"
- "Wikipedia Iron Man"
- "Weather in London"
- "Note that I need to buy milk"
- "Read my notes"
- "Tell me a joke"
- "Shut down" (to exit)

## Adding your own commands

All commands are routed through `jarvis/brain.py`. To add a new one:

1. Write a function in the relevant file under `jarvis/modules/` (or create a new module).
2. Add an `elif` rule in `handle_command()` in `brain.py` that checks for a
   trigger phrase and calls your function.

That's it — no need to touch the speech or main loop code.

## License

MIT — do whatever you like with it. See [LICENSE](LICENSE).
