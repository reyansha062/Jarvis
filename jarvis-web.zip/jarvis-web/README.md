# JARVIS — Browser HUD

A self-contained, single-file JARVIS-style assistant that runs entirely in the
browser — no install, no server, no Python. This is the version made to be
hosted on **GitHub Pages**.

It uses the browser's built-in Speech Recognition and Speech Synthesis APIs,
so voice in and voice out both work with zero backend.

## Why your last attempt 404'd

GitHub Pages only serves static files (HTML/CSS/JS) — it can't run a Python
script. The earlier JARVIS project (`jarvis-ai.zip`) was a Python desktop app,
which is why visiting it as a website gave "File not found." This project is
a plain `index.html`, which Pages *can* serve directly.

## Get it live at `your-username.github.io/Jarvis/`

1. Create a new GitHub repo named exactly `Jarvis` (case matters for the URL,
   though GitHub Pages itself isn't case-sensitive about the repo name).
2. Put `index.html` (this file) in the **root** of that repo — not inside a
   subfolder. GitHub Pages looks for `index.html` at the root by default.
3. Commit and push:
   ```bash
   git init
   git add index.html
   git commit -m "Add JARVIS HUD"
   git branch -M main
   git remote add origin https://github.com/YOUR-USERNAME/Jarvis.git
   git push -u origin main
   ```
4. In the repo, go to **Settings → Pages**, and under "Build and deployment"
   set **Source** to `Deploy from a branch`, branch `main`, folder `/root`.
5. Wait 1-2 minutes, then visit `https://YOUR-USERNAME.github.io/Jarvis/`.

If it still 404s, double check:
- `index.html` is at the **repo root**, not in a folder like `/web` or `/src`
- The filename is lowercase `index.html` exactly
- Pages is enabled in Settings → Pages and shows a green "Your site is live" banner

## Features

- 🎙️ Voice input via the Web Speech API (Chrome/Edge — best support)
- 🔊 Voice output via speech synthesis (works in most modern browsers)
- ⌨️ Text input as a fallback / alternative
- 🖥️ Animated arc-reactor HUD with a live transcript console
- 🌐 Wikipedia lookups, opening YouTube/Google/GitHub, web search
- 🕒 Time and date
- 📝 Notes saved in your browser's local storage
- ☁️ Weather lookups (asks once for a free OpenWeatherMap API key, stored
  locally in your browser — never sent anywhere but OpenWeatherMap)
- 🗣️ Personality — varied responses, not flat robotic replies

## Browser support note

Voice **input** (Speech Recognition) currently only works in Chromium-based
browsers (Chrome, Edge, Brave). Voice **output** (Speech Synthesis) works in
nearly all modern browsers. Text input always works everywhere as a fallback.

## Customizing

Everything lives in one file, `index.html`:
- Colors/fonts: edit the `:root` CSS variables near the top of `<style>`
- Assistant name / your name: edit `ASSISTANT_NAME` and `USER_NAME` near the
  top of the `<script>`
- Add new commands: add another `if (query.includes(...))` block inside
  `handleCommand()`

## License

MIT — do whatever you like with it.
