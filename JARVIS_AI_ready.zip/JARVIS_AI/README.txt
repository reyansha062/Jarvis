# JARVIS AI — Browser Edition

A ready-to-run JARVIS-style assistant for Windows/Chrome.

## Run
1. Extract the ZIP.
2. Open `index.html` in Chrome.
3. Allow microphone access when prompted.
4. Click **START LISTENING**.
5. Try:
   - "What is the time"
   - "What is today's date"
   - "Open Google"
   - "Open YouTube"
   - "Search Python tutorials"
   - "YouTube relaxing music"

## Important
This version is deliberately browser-safe. A GitHub Pages site cannot directly execute `adb`, `os.system`, or arbitrary Windows commands. Those require a local backend/bridge.

## GitHub Pages
Upload `index.html`, `style.css`, and `app.js` to a repository and enable GitHub Pages. The app is static and does not require a server.
