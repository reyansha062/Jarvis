const $ = id => document.getElementById(id);
const response = $("response"), heard = $("heard"), statusEl = $("status");
const logEl = $("log"), micBtn = $("micBtn"), textInput = $("textInput");
const orb = $("orb");

function addLog(who, text){
  const div = document.createElement("div");
  div.className = "line " + (who === "You" ? "you" : "jarvis");
  div.textContent = `[${new Date().toLocaleTimeString()}] ${who}: ${text}`;
  logEl.prepend(div);
}

function speak(text){
  if ("speechSynthesis" in window){
    speechSynthesis.cancel();
    const u = new SpeechSynthesisUtterance(text);
    u.rate = 1.02; u.pitch = 0.9; u.volume = 1;
    speechSynthesis.speak(u);
  }
}

function say(text){
  response.textContent = text;
  heard.textContent = "JARVIS is ready for your next command.";
  addLog("JARVIS", text);
  speak(text);
}

function openUrl(url){ window.open(url, "_blank", "noopener,noreferrer"); }

function execute(raw){
  const cmd = raw.trim().toLowerCase();
  if (!cmd) return;
  addLog("You", raw);
  heard.textContent = raw;

  if (cmd.includes("hello") || cmd.includes("hi jarvis")){
    say("Hello. All systems are online.");
  } else if (cmd.includes("time")){
    say("The time is " + new Date().toLocaleTimeString([], {hour:"numeric", minute:"2-digit"}));
  } else if (cmd.includes("date") || cmd.includes("today")){
    say("Today is " + new Date().toLocaleDateString([], {weekday:"long", year:"numeric", month:"long", day:"numeric"}));
  } else if (cmd.includes("open google")){
    say("Opening Google."); openUrl("https://www.google.com");
  } else if (cmd.includes("open youtube")){
    say("Opening YouTube."); openUrl("https://www.youtube.com");
  } else if (cmd.includes("open calculator")){
    say("Opening the calculator website.");
    openUrl("https://www.google.com/search?q=calculator");
  } else if (cmd.startsWith("search ")){
    const q = raw.slice(raw.toLowerCase().indexOf("search ") + 7).trim();
    say("Searching for " + q); openUrl("https://www.google.com/search?q=" + encodeURIComponent(q));
  } else if (cmd.startsWith("youtube ")){
    const q = raw.slice(raw.toLowerCase().indexOf("youtube ") + 8).trim();
    say("Searching YouTube for " + q); openUrl("https://www.youtube.com/results?search_query=" + encodeURIComponent(q));
  } else if (cmd.includes("who are you")){
    say("I am JARVIS, your browser-based personal assistant.");
  } else if (cmd.includes("clear log")){
    logEl.innerHTML = "";
    say("Activity log cleared.");
  } else {
    say("I can handle time, date, Google, YouTube, web search, and basic commands. Try saying search followed by your question.");
  }
}

let recognition = null;
const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;

if (SpeechRecognition){
  recognition = new SpeechRecognition();
  recognition.lang = "en-IN";
  recognition.continuous = false;
  recognition.interimResults = false;

  recognition.onstart = () => {
    orb.classList.add("listening");
    statusEl.textContent = "LISTENING...";
    micBtn.textContent = "🎙 LISTENING";
  };
  recognition.onend = () => {
    orb.classList.remove("listening");
    statusEl.textContent = "SYSTEM READY";
    micBtn.textContent = "🎙 START LISTENING";
  };
  recognition.onerror = e => {
    orb.classList.remove("listening");
    statusEl.textContent = "MIC ERROR";
    heard.textContent = "Microphone error: " + e.error;
  };
  recognition.onresult = e => execute(e.results[0][0].transcript);
} else {
  micBtn.disabled = true;
  micBtn.textContent = "🎙 VOICE NOT SUPPORTED";
  statusEl.textContent = "TEXT MODE";
}

micBtn.addEventListener("click", () => {
  if (recognition){
    try { recognition.start(); } catch (_) {}
  }
});
$("sendBtn").addEventListener("click", () => execute(textInput.value));
textInput.addEventListener("keydown", e => { if (e.key === "Enter") { execute(textInput.value); textInput.value = ""; } });
document.querySelectorAll("[data-command]").forEach(b => b.addEventListener("click", () => execute(b.dataset.command)));
$("clearBtn").addEventListener("click", () => logEl.innerHTML = "");

say("Hello. I am JARVIS. All systems are online.");
