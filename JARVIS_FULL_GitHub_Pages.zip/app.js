const $=id=>document.getElementById(id);
const answer=$("reply"),hint=$("sub"),log=$("log"),orb=$("orbArea"),mode=$("mode");
let voiceOn=true,memoryOn=true,autoSpeak=true,wakeOn=false,recognition=null;
function addLog(who,text){const d=document.createElement("div");d.className="line "+(who==="You"?"you":"jarvis");d.textContent="["+new Date().toLocaleTimeString()+"] "+who+": "+text;log.prepend(d);if(memoryOn)localStorage.setItem("jarvisLog",log.innerHTML)}
function speak(text){if(!voiceOn||!autoSpeak||!("speechSynthesis"in window))return;speechSynthesis.cancel();const u=new SpeechSynthesisUtterance(text);u.rate=1;u.pitch=.88;u.volume=1;speechSynthesis.speak(u)}
function reply(text){answer.textContent=text;hint.textContent="JARVIS is ready for your next command.";addLog("JARVIS",text);speak(text)}
function openWeb(url){window.open(url,"_blank","noopener,noreferrer")}
function execute(raw){if(!raw||!raw.trim())return;const cmd=raw.trim(),c=cmd.toLowerCase();addLog("You",cmd);hint.textContent=cmd;
if(c==="help"||c.includes("what can you do"))reply("I can handle voice commands, web search, YouTube, Google, maps, weather, calculator, time, date and browser-safe assistant commands.");
else if(c.includes("hello")||c.includes("hi jarvis"))reply("Hello. All systems are online.");
else if(c.includes("time"))reply("The current time is "+new Date().toLocaleTimeString([],{hour:"numeric",minute:"2-digit"}));
else if(c.includes("date")||c.includes("today"))reply("Today is "+new Date().toLocaleDateString([],{weekday:"long",year:"numeric",month:"long",day:"numeric"}));
else if(c.includes("open google")){reply("Opening Google.");openWeb("https://www.google.com")}
else if(c.includes("open youtube")){reply("Opening YouTube.");openWeb("https://www.youtube.com")}
else if(c.includes("open maps")||c.includes("google maps")){reply("Opening Google Maps.");openWeb("https://maps.google.com")}
else if(c.includes("calculator")){reply("Opening calculator.");openWeb("https://www.google.com/search?q=calculator")}
else if(c.includes("weather")){let q=c.replace("weather","").replace("in ","").trim();reply("Opening weather"+(q?" for "+q:"")+" .");openWeb("https://www.google.com/search?q="+encodeURIComponent("weather "+q))}
else if(c.startsWith("youtube ")){const q=cmd.slice(8).trim();reply("Searching YouTube for "+q);openWeb("https://www.youtube.com/results?search_query="+encodeURIComponent(q))}
else if(c.startsWith("search ")){const q=cmd.slice(7).trim();reply("Searching for "+q);openWeb("https://www.google.com/search?q="+encodeURIComponent(q))}
else if(c.includes("who are you"))reply("I am JARVIS, your browser-based personal AI command center.");
else if(c.includes("clear log")){log.innerHTML="";localStorage.removeItem("jarvisLog");reply("Activity log cleared.")}
else reply("I did not recognize that command. Say help to hear what I can do.")}
const SR=window.SpeechRecognition||window.webkitSpeechRecognition;
if(SR){recognition=new SR();recognition.lang="en-IN";recognition.continuous=false;recognition.interimResults=false;
recognition.onstart=()=>{orb.classList.add("listening");mode.textContent="LISTENING";$("voiceState").textContent="LISTENING";$("systemState").textContent="VOICE ACTIVE"};
recognition.onend=()=>{orb.classList.remove("listening");mode.textContent="TEXT + VOICE";$("voiceState").textContent="READY";$("systemState").textContent="SYSTEM ONLINE"};
recognition.onerror=e=>{orb.classList.remove("listening");mode.textContent="MIC ERROR";hint.textContent="Microphone error: "+e.error};
recognition.onresult=e=>{const text=e.results[0][0].transcript;if(wakeOn&&!text.toLowerCase().includes("jarvis"))return;execute(text.replace(/hey jarvis/ig,"").replace(/jarvis/ig,"").trim())}}
else{$("listenBtn").disabled=true;mode.textContent="TEXT ONLY";$("voiceState").textContent="UNAVAILABLE"}
$("listenBtn").onclick=()=>{if(recognition)try{recognition.start()}catch(e){}};
$("stopBtn").onclick=()=>{if(recognition)recognition.stop();if("speechSynthesis"in window)speechSynthesis.cancel();orb.classList.remove("listening")};
$("wakeBtn").onclick=()=>{wakeOn=!wakeOn;$("wakeBtn").textContent="WAKE WORD: "+(wakeOn?"ON":"OFF");mode.textContent=wakeOn?"SAY “HEY JARVIS”":"TEXT + VOICE"};
$("sendBtn").onclick=()=>{$("command").value&&(execute($("command").value),$("command").value="",$("command").focus())};
$("command").onkeydown=e=>{if(e.key==="Enter")$("sendBtn").click()};
document.querySelectorAll("[data-cmd]").forEach(b=>b.onclick=()=>execute(b.dataset.cmd));
$("clearBtn").onclick=()=>{log.innerHTML="";localStorage.removeItem("jarvisLog")};
$("settingsBtn").onclick=()=>$("settings").classList.remove("hidden");
$("closeSettings").onclick=()=>$("settings").classList.add("hidden");
$("voiceToggle").onchange=e=>{voiceOn=e.target.checked};
$("memoryToggle").onchange=e=>{memoryOn=e.target.checked;if(!memoryOn)localStorage.removeItem("jarvisLog")};
$("autoSpeakToggle").onchange=e=>{autoSpeak=e.target.checked};
setInterval(()=>$("clock").textContent=new Date().toLocaleTimeString(),1000);
try{if(localStorage.getItem("jarvisLog"))log.innerHTML=localStorage.getItem("jarvisLog")}catch(e){}
$("clock").textContent=new Date().toLocaleTimeString();
reply("Good day. I am JARVIS. All systems are online.");