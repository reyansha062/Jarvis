JARVIS FULL GITHUB PAGES EDITION
Put index.html, style.css, and app.js in the ROOT of your GitHub Pages repository.
Settings > Pages > Deploy from a branch > main > / (root).
GitHub Pages cannot directly execute Windows commands or Android ADB; a local bridge is required for those capabilities.
