const $=id=>document.getElementById(id);
let recognition=null, speaking=true, busy=false;

function log(who,text){const d=document.createElement("div");d.className="line "+(who==="You"?"you":"jarvis");d.textContent=`[${new Date().toLocaleTimeString()}] ${who}: ${text}`;$("log").prepend(d)}
function speak(text){if(!speaking||!window.speechSynthesis)return;speechSynthesis.cancel();const u=new SpeechSynthesisUtterance(text);u.rate=.97;u.pitch=.85;speechSynthesis.speak(u)}
function show(text,detail=""){ $("answer").textContent=text; $("detail").textContent=detail; log("JARVIS",text); speak(text)}
function doAction(a){
 if(!a||!a.type)return;
 const q=encodeURIComponent(a.query||"");
 const urls={google:"https://www.google.com/search?q="+q,youtube:"https://www.youtube.com/results?search_query="+q,maps:"https://www.google.com/maps/search/?api=1&query="+q,weather:"https://www.google.com/search?q="+encodeURIComponent("weather "+(a.query||""))};
 if(a.type==="open_url"&&a.url)window.open(a.url,"_blank","noopener,noreferrer");
 else if(urls[a.type])window.open(urls[a.type],"_blank","noopener,noreferrer");
 else if(a.type==="timer"){const s=Math.max(1,Number(a.seconds)||1);setTimeout(()=>{show("Timer complete.","Your "+s+" second timer has finished.");alert("JARVIS: Timer complete.");},s*1000)}
}
async function ask(text){
 if(busy)return; text=text.trim(); if(!text)return;
 busy=true;$("status").textContent="THINKING";$("mode").textContent="GEMINI THINKING";$("orb").classList.add("listening");log("You",text);
 try{
  const r=await fetch("/api/chat",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({message:text})});
  const data=await r.json(); if(!r.ok)throw new Error(data.error||"Backend error");
  show(data.reply||"I received that.",data.action?"Action: "+data.action.type:"Gemini response");
  if(data.action)doAction(data.action);
 }catch(e){show("I couldn't reach my Gemini brain.","Make sure the backend is running and GEMINI_API_KEY is configured.");console.error(e)}
 finally{busy=false;$("status").textContent="ONLINE";$("mode").textContent="GEMINI READY";$("orb").classList.remove("listening")}
}
$("send").onclick=()=>{$("cmd").value&&(ask($("cmd").value),$("cmd").value="")};
$("cmd").onkeydown=e=>{if(e.key==="Enter")$("send").click()};
document.querySelectorAll("[data-q]").forEach(b=>b.onclick=()=>ask(b.dataset.q));
$("clear").onclick=()=>{$("log").innerHTML=""};
$("stop").onclick=()=>{try{recognition?.stop()}catch{}speechSynthesis?.cancel();$("orb").classList.remove("listening");$("status").textContent="ONLINE"};
const SR=window.SpeechRecognition||window.webkitSpeechRecognition;
if(SR){recognition=new SR();recognition.lang="en-IN";recognition.continuous=false;recognition.interimResults=false;
 recognition.onstart=()=>{$("voice").textContent="LISTENING";$("status").textContent="LISTENING";$("orb").classList.add("listening")};
 recognition.onend=()=>{$("voice").textContent="READY";$("status").textContent="ONLINE";$("orb").classList.remove("listening")};
 recognition.onerror=e=>{$("voice").textContent="ERROR";show("Microphone error.","Try Chrome/Edge and allow microphone permission.")};
 recognition.onresult=e=>ask(e.results[0][0].transcript);
}else{$("mic").disabled=true;$("voice").textContent="UNAVAILABLE"}
$("mic").onclick=()=>{try{recognition?.start()}catch{}};
fetch("/api/health").then(r=>r.json()).then(x=>{$("backend").textContent=x.ok?"ONLINE":"OFFLINE"}).catch(()=>{$("backend").textContent="OFFLINE"});
